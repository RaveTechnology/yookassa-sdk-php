# [YooKassa API SDK](../home.md)

# Class: \YooKassa\Helpers\UUID
### Namespace: [\YooKassa\Helpers](../namespaces/yookassa-helpers.md)
---

---
### Constants
* No constants found

---
### Methods
| Visibility | Name | Flag | Summary |
| ----------:| ---- | ---- | ------- |
| public | [v4()](../classes/YooKassa-Helpers-UUID.md#method_v4) |  |  |

---
### Details
* File: [lib/Helpers/UUID.php](../../lib/Helpers/UUID.php)
* Package: Default
* Class Hierarchy:
  * \YooKassa\Helpers\UUID

---
## Methods
<a name="method_v4" class="anchor"></a>
#### public v4() : string

```php
Static public v4() : string
```

**Details:**
* Inherited From: [\YooKassa\Helpers\UUID](../classes/YooKassa-Helpers-UUID.md)

##### Throws:
| Type | Description |
| ---- | ----------- |
| \Exception |  |

**Returns:** string - 



---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 1](../reports/markers.md)
* [Deprecated - 43](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2025-09-04 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2025 YooMoney