# [YooKassa API SDK](../home.md)

# Class: \YooKassa\Helpers\RawHeadersParser
### Namespace: [\YooKassa\Helpers](../namespaces/yookassa-helpers.md)
---

---
### Constants
* No constants found

---
### Methods
| Visibility | Name | Flag | Summary |
| ----------:| ---- | ---- | ------- |
| public | [parse()](../classes/YooKassa-Helpers-RawHeadersParser.md#method_parse) |  |  |

---
### Details
* File: [lib/Helpers/RawHeadersParser.php](../../lib/Helpers/RawHeadersParser.php)
* Package: Default
* Class Hierarchy:
  * \YooKassa\Helpers\RawHeadersParser

---
## Methods
<a name="method_parse" class="anchor"></a>
#### public parse() : mixed

```php
Static public parse(mixed $rawHeaders) : mixed
```

**Details:**
* Inherited From: [\YooKassa\Helpers\RawHeadersParser](../classes/YooKassa-Helpers-RawHeadersParser.md)

##### Parameters:
| Type | Name | Description |
| ---- | ---- | ----------- |
| <code lang="php">mixed</code> | rawHeaders  |  |

**Returns:** mixed - 



---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 1](../reports/markers.md)
* [Deprecated - 43](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2025-09-04 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2025 YooMoney