# [YooKassa API SDK](../home.md)

# Interface: JsonSerializable
### Namespace: [\](../namespaces/default.md)
---
---
### Constants
* No constants found

---
### Methods
| Visibility | Name | Flag | Summary |
| ----------:| ---- | ---- | ------- |
| public | [jsonSerialize()](../classes/JsonSerializable.md#method_jsonSerialize) |  |  |

---
### Details
* File: [lib/Common/legacy_json_serializable.php](../../lib/Common/legacy_json_serializable.php)
* Package: \Default

---
## Methods
<a name="method_jsonSerialize" class="anchor"></a>
#### public jsonSerialize() : mixed

```php
public jsonSerialize() : mixed
```

**Details:**
* Inherited From: [\JsonSerializable](../classes/JsonSerializable.md)

**Returns:** mixed - 




---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 1](../reports/markers.md)
* [Deprecated - 43](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2025-09-04 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2025 YooMoney