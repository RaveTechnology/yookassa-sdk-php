# [YooKassa API SDK](../home.md)

# Markers
* 1 - lib/Request/SelfEmployed/SelfEmployedRequestBuilder.php
### 1 - lib/Request/SelfEmployed/SelfEmployedRequestBuilder.php
| Line | Type | Description |
| ---- | ---- | ----------- |
| 41 | TODO | @example 02-builder.php 11 78 Пример использования билдера |

---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 1](../reports/markers.md)
* [Deprecated - 43](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2025-09-04 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2025 YooMoney