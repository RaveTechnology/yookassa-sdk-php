# [YooKassa API SDK](../home.md)

# Namespace: \YooKassa\Model\Webhook

## Parent: [\YooKassa\Model](../namespaces/yookassa-model.md)

### Classes

| Name | Summary |
| ---- | ------- |
| [\YooKassa\Model\Webhook\Webhook](../classes/YooKassa-Model-Webhook-Webhook.md) | Класс Webhook содержит информацию о подписке на одно событие |

---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 1](../reports/markers.md)
* [Deprecated - 43](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2025-09-04 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2025 YooMoney