# [YooKassa API SDK](../home.md)

# Namespace: \YooKassa\Model\PaymentMethod\B2b\Sberbank

## Parent: [\YooKassa\Model\PaymentMethod\B2b](../namespaces/yookassa-model-paymentmethod-b2b.md)

### Interfaces

| Name | Summary |
| ---- | ------- |
| [\YooKassa\Model\PaymentMethod\B2b\Sberbank\PayerBankDetailsInterface](../classes/YooKassa-Model-PaymentMethod-B2b-Sberbank-PayerBankDetailsInterface.md) | Interface PayerBankDetailsInterface |

### Classes

| Name | Summary |
| ---- | ------- |
| [\YooKassa\Model\PaymentMethod\B2b\Sberbank\PayerBankDetails](../classes/YooKassa-Model-PaymentMethod-B2b-Sberbank-PayerBankDetails.md) | Банковские реквизиты плательщика |

---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 1](../reports/markers.md)
* [Deprecated - 43](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2025-09-04 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2025 YooMoney