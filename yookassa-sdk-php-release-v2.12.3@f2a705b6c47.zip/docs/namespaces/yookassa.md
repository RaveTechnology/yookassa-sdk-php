# [YooKassa API SDK](../home.md)

# Namespace: \YooKassa

## Parent: [default](../namespaces/default.md)

### Namespaces

* [\YooKassa\Client](../namespaces/yookassa-client.md)
* [\YooKassa\Common](../namespaces/yookassa-common.md)
* [\YooKassa\Helpers](../namespaces/yookassa-helpers.md)
* [\YooKassa\Model](../namespaces/yookassa-model.md)
* [\YooKassa\Request](../namespaces/yookassa-request.md)

### Classes

| Name | Summary |
| ---- | ------- |
| [\YooKassa\Client](../classes/YooKassa-Client.md) | Класс клиента API |

---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 1](../reports/markers.md)
* [Deprecated - 43](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2025-09-04 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2025 YooMoney