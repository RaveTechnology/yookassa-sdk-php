# [YooKassa API SDK](../home.md)

# Namespace: \YooKassa\Client

## Parent: [\YooKassa](../namespaces/yookassa.md)

### Interfaces

| Name | Summary |
| ---- | ------- |
| [\YooKassa\Client\ApiClientInterface](../classes/YooKassa-Client-ApiClientInterface.md) | Interface ApiClientInterface |

### Classes

| Name | Summary |
| ---- | ------- |
| [\YooKassa\Client\BaseClient](../classes/YooKassa-Client-BaseClient.md) |  |
| [\YooKassa\Client\CurlClient](../classes/YooKassa-Client-CurlClient.md) | Класс клиента Curl запросов |
| [\YooKassa\Client\UserAgent](../classes/YooKassa-Client-UserAgent.md) | Класс для создания заголовка User-Agent в запросах к API |

---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 1](../reports/markers.md)
* [Deprecated - 43](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2025-09-04 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2025 YooMoney